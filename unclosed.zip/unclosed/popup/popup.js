/* Unclosed — popup. Writes to chrome.storage.sync; open LeetCode tabs react instantly. */
const DEFAULTS = { enabled: true, celebrate: true };
const $ = (id) => document.getElementById(id);

const enabledEl = $('enabled');
const celebrateEl = $('celebrate');

function paint(enabled) {
  document.body.classList.toggle('paused', !enabled);
  $('enabledSub').textContent = enabled ? '( [ { " \' stay single' : 'paused: LeetCode auto-closes';
  const out = $('previewOut');
  out.textContent = '(';
  const closer = document.createElement('span');
  closer.textContent = ')';
  if (enabled) closer.className = 'blocked'; // crossed out = never inserted
  out.append(closer);
}

chrome.storage.sync.get(DEFAULTS, (s) => {
  enabledEl.checked = s.enabled;
  celebrateEl.checked = s.celebrate;
  paint(s.enabled);
});
chrome.storage.local.get({ acCount: 0 }, ({ acCount }) => { $('acCount').textContent = acCount; });

enabledEl.addEventListener('change', () => {
  const on = enabledEl.checked;
  chrome.storage.sync.set({ enabled: on });
  paint(on);
  if (on) sparkle();
});
celebrateEl.addEventListener('change', () => {
  chrome.storage.sync.set({ celebrate: celebrateEl.checked });
});

// Show the shortcut the user actually has bound (they can change it at chrome://extensions/shortcuts).
chrome.commands.getAll((cmds) => {
  const c = cmds.find((x) => x.name === 'toggle-unclosed');
  $('shortcut').textContent = (c && c.shortcut) || 'set a shortcut';
});

/* ---- talk to the active LeetCode tab ---- */
function withTab(fn) {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => tab && fn(tab.id));
}

withTab((id) => {
  chrome.tabs.sendMessage(id, { type: 'getStatus' }, (res) => {
    if (chrome.runtime.lastError || !res) return; // not a LeetCode tab
    const el = $('status');
    el.classList.add('ok');
    const parts = [];
    if (res.monaco) parts.push(`Monaco ✓ ×${res.monacoEditors}`);
    if (res.codemirror) parts.push('CodeMirror ✓');
    el.textContent = parts.length ? `connected · ${parts.join(' · ')}` : 'connected · waiting for the editor…';
  });
});

$('previewBtn').addEventListener('click', () => {
  sparkle();
  withTab((id) => chrome.tabs.sendMessage(id, { type: 'preview' }, () => void chrome.runtime.lastError));
});

/* ---- tiny sparkle burst inside the popup ---- */
function sparkle() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const c = $('fx');
  const dpr = window.devicePixelRatio || 1;
  c.width = c.clientWidth * dpr;
  c.height = c.clientHeight * dpr;
  const ctx = c.getContext('2d');
  ctx.scale(dpr, dpr);
  const colors = ['#ffffff', '#fde68a', '#f0abfc', '#a5f3fc', '#c4b5fd', '#f472b6'];
  const ox = 40, oy = 40; // from the logo
  const ps = Array.from({ length: 36 }, () => {
    const a = Math.random() * Math.PI * 2;
    const v = 1.5 + Math.random() * 3.5;
    return { x: ox, y: oy, vx: Math.cos(a) * v, vy: Math.sin(a) * v, s: 3 + Math.random() * 5,
      c: colors[(Math.random() * colors.length) | 0], life: 0, ttl: 40 + Math.random() * 30 };
  });
  (function frame() {
    ctx.clearRect(0, 0, c.clientWidth, c.clientHeight);
    let alive = 0;
    for (const p of ps) {
      if (++p.life > p.ttl) continue;
      alive++;
      p.vx *= 0.95; p.vy = p.vy * 0.95 + 0.05;
      p.x += p.vx; p.y += p.vy;
      const s = p.s * (0.6 + 0.4 * Math.abs(Math.sin(p.life * 0.3)));
      ctx.globalAlpha = 1 - p.life / p.ttl;
      ctx.fillStyle = p.c;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y - s);
      ctx.quadraticCurveTo(p.x, p.y, p.x + s, p.y);
      ctx.quadraticCurveTo(p.x, p.y, p.x, p.y + s);
      ctx.quadraticCurveTo(p.x, p.y, p.x - s, p.y);
      ctx.quadraticCurveTo(p.x, p.y, p.x, p.y - s);
      ctx.fill();
    }
    if (alive) requestAnimationFrame(frame);
    else ctx.clearRect(0, 0, c.clientWidth, c.clientHeight);
  })();
}
