/* Unclosed — service worker: keyboard shortcut + toolbar badge. */
const DEFAULTS = { enabled: true, celebrate: true };

function paintBadge(enabled) {
  chrome.action.setBadgeText({ text: enabled ? '' : 'OFF' });
  chrome.action.setBadgeBackgroundColor({ color: '#475569' });
  chrome.action.setTitle({
    title: enabled
      ? 'Unclosed — auto-close blocked 🔓 (Alt+Shift+U to toggle)'
      : 'Unclosed — paused, LeetCode auto-closes again',
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(DEFAULTS, (s) => {
    chrome.storage.sync.set(s); // write defaults on first install, keep existing on update
    paintBadge(s.enabled);
  });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.storage.sync.get(DEFAULTS, (s) => paintBadge(s.enabled));
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync' && changes.enabled) paintBadge(changes.enabled.newValue !== false);
});

chrome.commands.onCommand.addListener((command) => {
  if (command !== 'toggle-unclosed') return;
  chrome.storage.sync.get(DEFAULTS, (s) => chrome.storage.sync.set({ enabled: !s.enabled }));
});
