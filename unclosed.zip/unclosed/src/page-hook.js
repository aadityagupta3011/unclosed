/*
 * Unclosed — page hook (runs in the page's MAIN world at document_start).
 *
 * Why MAIN world: LeetCode's editors (Monaco for code, CodeMirror 6 for the
 * testcase box) are JS objects owned by the page. An isolated-world content
 * script can see the DOM but not those objects, so it can't change their config.
 *
 * What it does:
 *   1. Monaco  -> sets autoClosingBrackets / autoClosingQuotes / autoSurround to
 *                 "never" on every editor (existing + future), and restores the
 *                 original values when you toggle off.
 *   2. CodeMirror 6 -> its closeBrackets extension can't be reconfigured from
 *                 outside, so opening chars are handled at the input level:
 *                 the keystroke is turned into a plain insert transaction before
 *                 closeBrackets ever sees it. Nothing is deleted after the fact.
 *   3. CodeMirror 5 -> setOption('autoCloseBrackets', false), in case LeetCode
 *                 ever serves it.
 *   4. Watches submission results so the extension can celebrate an Accepted.
 *
 * It talks to the isolated content script with CustomEvents carrying JSON strings.
 */
(() => {
  'use strict';

  const FLAG = '__unclosedHooked';
  if (window[FLAG]) return;
  Object.defineProperty(window, FLAG, { value: true });

  const TO_EXT = 'unclosed:to-ext';
  const TO_PAGE = 'unclosed:to-page';

  const OVERRIDE = Object.freeze({
    autoClosingBrackets: 'never',
    autoClosingQuotes: 'never',
    autoSurround: 'never',
  });
  const KEYS = Object.keys(OVERRIDE);
  const OPENERS = new Set(['(', '[', '{', '"', "'", '`']);

  let enabled = true; // default until the content script reports the saved setting
  let statusTimer = 0; // declared up front: reportStatus() can run during the global trap below

  const emit = (type, data = {}) => {
    try {
      document.dispatchEvent(
        new CustomEvent(TO_EXT, { detail: JSON.stringify({ type, ...data }) })
      );
    } catch (_) { /* never let messaging break the page */ }
  };

  /* ------------------------------------------------------------------ */
  /* Monaco                                                              */
  /* ------------------------------------------------------------------ */

  let monacoApi = null;
  const editors = new Set();          // live Monaco editors we manage
  const wanted = new WeakMap();       // editor -> the values the page itself wants
  const rawUpdate = new WeakMap();    // editor -> original updateOptions

  function applyMonaco(ed) {
    const update = rawUpdate.get(ed);
    if (!update) return;
    try {
      update.call(ed, enabled ? OVERRIDE : { ...wanted.get(ed) });
    } catch (_) { /* editor may be mid-dispose */ }
  }

  function adoptEditor(ed) {
    if (!ed || rawUpdate.has(ed) || typeof ed.updateOptions !== 'function') return;

    // Remember what the page configured, so toggling off restores it exactly.
    const raw = (typeof ed.getRawOptions === 'function' && ed.getRawOptions()) || {};
    const pageWants = {};
    for (const k of KEYS) pageWants[k] = raw[k] !== undefined ? raw[k] : 'languageDefined';
    wanted.set(ed, pageWants);

    // Wrap updateOptions so LeetCode re-applying its own settings (font size,
    // tab size, theme changes...) can't silently switch auto-closing back on.
    const original = ed.updateOptions;
    rawUpdate.set(ed, original);
    ed.updateOptions = function (opts) {
      if (opts && typeof opts === 'object') {
        let touched = false;
        const next = { ...opts };
        for (const k of KEYS) {
          if (k in next) {
            pageWants[k] = next[k];
            if (enabled) { next[k] = OVERRIDE[k]; touched = true; }
          }
        }
        if (touched) return original.call(this, next);
      }
      return original.apply(this, arguments);
    };

    editors.add(ed);
    if (typeof ed.onDidDispose === 'function') {
      ed.onDidDispose(() => { editors.delete(ed); reportStatus(); });
    }
    applyMonaco(ed);
    reportStatus();
  }

  function hookMonaco(api) {
    if (!api || api === monacoApi) return false;
    const ns = api.editor;
    if (!ns || typeof ns.onDidCreateEditor !== 'function') return false;
    monacoApi = api;
    ns.onDidCreateEditor(adoptEditor); // fires for every editor created from now on
    if (typeof ns.getEditors === 'function') ns.getEditors().forEach(adoptEditor);
    reportStatus();
    return true;
  }

  // Catch `window.monaco` the moment Monaco's loader publishes it, rather than
  // assuming it already exists. The scanner below is a second line of defence.
  (function trapGlobal() {
    const desc = Object.getOwnPropertyDescriptor(window, 'monaco');
    if (desc && !desc.configurable) return;
    let current = desc ? (desc.get ? desc.get.call(window) : desc.value) : undefined;
    if (current) hookMonaco(current);
    try {
      Object.defineProperty(window, 'monaco', {
        configurable: true,
        enumerable: true,
        get() { return current; },
        set(v) { current = v; try { hookMonaco(v); } catch (_) {} },
      });
    } catch (_) { /* fall back to the scanner */ }
  })();

  function findMonaco() {
    if (monacoApi) return;
    if (hookMonaco(window.monaco)) return;
    // AMD build of Monaco (vs/loader): ask the loader for the already-loaded module.
    const req = window.require;
    if (typeof req === 'function' && typeof req.config === 'function') {
      try { req(['vs/editor/editor.main'], (m) => hookMonaco(m || window.monaco)); } catch (_) {}
    }
  }

  /* ------------------------------------------------------------------ */
  /* CodeMirror 6 (testcase box) — input-level interception              */
  /* ------------------------------------------------------------------ */

  function cm6ViewFrom(el) {
    const content = el && el.closest ? el.closest('.cm-content') : null;
    if (!content) return null;
    const desc = content.cmView || content.cmTile;
    const view = desc && (desc.view || (desc.rootView && desc.rootView.view));
    return view && typeof view.dispatch === 'function' && view.state ? view : null;
  }

  document.addEventListener('keydown', (e) => {
    if (!enabled || e.defaultPrevented || e.isComposing || e.keyCode === 229) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return; // leave shortcuts alone
    if (!OPENERS.has(e.key)) return;
    const view = cm6ViewFrom(e.target);
    if (!view || view.state.readOnly) return;

    // Insert exactly the typed character as a normal typing transaction
    // (undo-groups like regular typing). closeBrackets never runs.
    e.preventDefault();
    e.stopImmediatePropagation();
    const spec = view.state.replaceSelection(e.key);
    view.dispatch(spec, { scrollIntoView: true, userEvent: 'input.type' });
  }, true);

  /* ------------------------------------------------------------------ */
  /* CodeMirror 5 (legacy, just in case)                                 */
  /* ------------------------------------------------------------------ */

  const cm5Original = new WeakMap();
  function applyCM5() {
    document.querySelectorAll('.CodeMirror').forEach((el) => {
      const cm = el.CodeMirror;
      if (!cm || typeof cm.setOption !== 'function') return;
      if (!cm5Original.has(cm)) cm5Original.set(cm, cm.getOption('autoCloseBrackets'));
      try { cm.setOption('autoCloseBrackets', enabled ? false : cm5Original.get(cm)); } catch (_) {}
    });
  }

  /* ------------------------------------------------------------------ */
  /* State                                                               */
  /* ------------------------------------------------------------------ */

  function applyAll() {
    editors.forEach(applyMonaco);
    applyCM5();
    reportStatus();
  }

  function reportStatus() {
    clearTimeout(statusTimer);
    statusTimer = setTimeout(() => {
      emit('status', {
        enabled,
        monaco: !!monacoApi,
        monacoEditors: editors.size,
        codemirror: document.querySelectorAll('.cm-editor').length +
                    document.querySelectorAll('.CodeMirror').length,
      });
    }, 50);
  }

  document.addEventListener(TO_PAGE, (e) => {
    let msg;
    try { msg = JSON.parse(e.detail); } catch (_) { return; }
    if (msg && msg.type === 'state' && typeof msg.enabled === 'boolean') {
      if (msg.enabled !== enabled) { enabled = msg.enabled; applyAll(); }
      else reportStatus();
    }
  });

  /* ------------------------------------------------------------------ */
  /* Accepted detection                                                  */
  /* ------------------------------------------------------------------ */

  const SUBMIT_RE = /\/problems\/[^/]+\/submit\/?$/;
  const CHECK_RE = /\/submissions\/detail\/([^/]+)\/check\/?$/;
  const pendingSubs = new Set();
  let lastSubmitAt = 0;
  let celebratedSubmitAt = -1;
  const staleResultEls = new WeakSet();

  function pathOf(url) {
    try { return new URL(url, location.href).pathname; } catch (_) { return ''; }
  }

  function interesting(url) {
    const p = pathOf(url);
    return SUBMIT_RE.test(p) || CHECK_RE.test(p);
  }

  function markSubmitStarted() {
    lastSubmitAt = Date.now();
    const el = document.querySelector('[data-e2e-locator="submission-result"]');
    if (el) staleResultEls.add(el); // an old "Accepted" on screen must not count
  }

  function fireAccepted(source) {
    if (celebratedSubmitAt === lastSubmitAt) return; // one party per submission
    celebratedSubmitAt = lastSubmitAt;
    emit('accepted', { source });
  }

  function onResponse(url, method, readJson) {
    const path = pathOf(url);
    if (SUBMIT_RE.test(path) && method === 'POST') {
      markSubmitStarted();
      readJson().then((j) => {
        if (j && j.submission_id != null) pendingSubs.add(String(j.submission_id));
      }).catch(() => {});
      return;
    }
    const m = path.match(CHECK_RE);
    if (!m || m[1].startsWith('runcode')) return; // "Run" results are not submissions
    readJson().then((j) => {
      if (!j || j.state !== 'SUCCESS') return;
      if (typeof j.task_name === 'string' && /runcode/i.test(j.task_name)) return;
      const id = m[1];
      const ours = pendingSubs.delete(id) || Date.now() - lastSubmitAt < 120000;
      if (ours && (j.status_code === 10 || j.status_msg === 'Accepted')) fireAccepted('network');
    }).catch(() => {});
  }

  // fetch — observe only; the page always gets the original response.
  const nativeFetch = window.fetch;
  if (typeof nativeFetch === 'function') {
    window.fetch = function (input, init) {
      const p = nativeFetch.apply(this, arguments);
      try {
        const url = typeof input === 'string' ? input : (input && input.url) || String(input);
        if (interesting(url)) {
          const method = String((init && init.method) || (input && input.method) || 'GET').toUpperCase();
          p.then((res) => onResponse(url, method, () => res.clone().json())).catch(() => {});
        }
      } catch (_) {}
      return p;
    };
  }

  // XMLHttpRequest
  const XHR = XMLHttpRequest.prototype;
  const nativeOpen = XHR.open;
  const nativeSend = XHR.send;
  const meta = new WeakMap();
  XHR.open = function (method, url) {
    try { meta.set(this, { method: String(method).toUpperCase(), url: String(url) }); } catch (_) {}
    return nativeOpen.apply(this, arguments);
  };
  XHR.send = function () {
    const info = meta.get(this);
    if (info && interesting(info.url)) {
      this.addEventListener('load', () => {
        onResponse(info.url, info.method, () => new Promise((resolve, reject) => {
          try {
            resolve(this.responseType === 'json' ? this.response : JSON.parse(this.responseText));
          } catch (err) { reject(err); }
        }));
      });
    }
    return nativeSend.apply(this, arguments);
  };

  // Submit button / Cmd+Enter: mark the start so the DOM fallback knows a
  // fresh result is coming.
  document.addEventListener('click', (e) => {
    if (e.target && e.target.closest && e.target.closest('[data-e2e-locator="console-submit-button"]')) {
      markSubmitStarted();
    }
  }, true);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey) && !e.shiftKey && !e.altKey) markSubmitStarted();
  }, true);

  function checkResultDom() {
    if (!lastSubmitAt || Date.now() - lastSubmitAt > 90000) return;
    if (celebratedSubmitAt === lastSubmitAt) return;
    const el = document.querySelector('[data-e2e-locator="submission-result"]');
    if (el && !staleResultEls.has(el) && /\bAccepted\b/.test(el.textContent || '')) {
      staleResultEls.add(el);
      fireAccepted('dom');
    }
  }

  /* ------------------------------------------------------------------ */
  /* Scanner: SPA navigation, late-loaded editors, DOM fallback          */
  /* ------------------------------------------------------------------ */

  let scanQueued = false;
  function scan() {
    scanQueued = false;
    if (!monacoApi && document.querySelector('.monaco-editor')) findMonaco();
    if (monacoApi && typeof monacoApi.editor.getEditors === 'function') {
      monacoApi.editor.getEditors().forEach(adoptEditor); // cheap: adopted ones are skipped
    }
    if (document.querySelector('.CodeMirror')) applyCM5();
    checkResultDom();
  }
  function queueScan() {
    if (scanQueued) return;
    scanQueued = true;
    setTimeout(scan, 250);
  }

  const startObserver = () => {
    new MutationObserver(queueScan).observe(document.documentElement, { childList: true, subtree: true });
    queueScan();
  };
  if (document.documentElement) startObserver();
  else document.addEventListener('readystatechange', startObserver, { once: true });

  emit('hello');
})();
