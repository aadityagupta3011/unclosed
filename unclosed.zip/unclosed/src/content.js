/*
 * Unclosed — content script (isolated world).
 * Bridges chrome.storage <-> the MAIN-world page hook, and runs the effects.
 */
(() => {
  'use strict';

  const TO_EXT = 'unclosed:to-ext';
  const TO_PAGE = 'unclosed:to-page';
  const DEFAULTS = { enabled: true, celebrate: true };

  let settings = { ...DEFAULTS };
  let loaded = false;
  let status = { monaco: false, monacoEditors: 0, codemirror: 0 };

  const toPage = (msg) =>
    document.dispatchEvent(new CustomEvent(TO_PAGE, { detail: JSON.stringify(msg) }));
  const pushState = () => loaded && toPage({ type: 'state', enabled: settings.enabled });

  chrome.storage.sync.get(DEFAULTS, (stored) => {
    settings = { ...DEFAULTS, ...stored };
    loaded = true;
    pushState();
  });

  // Live toggle from the popup / keyboard shortcut / another tab.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    let flipped = null;
    for (const [key, { newValue }] of Object.entries(changes)) {
      if (!(key in DEFAULTS)) continue;
      if (key === 'enabled' && newValue !== settings.enabled) flipped = newValue;
      settings[key] = newValue === undefined ? DEFAULTS[key] : newValue;
    }
    if (flipped === null) return;
    pushState();
    if (document.visibilityState === 'visible') window.UnclosedFX.toggled(flipped);
  });

  document.addEventListener(TO_EXT, (e) => {
    let msg;
    try { msg = JSON.parse(e.detail); } catch (_) { return; }
    if (!msg) return;
    switch (msg.type) {
      case 'hello':
        pushState();
        break;
      case 'status':
        status = msg;
        break;
      case 'accepted':
        if (settings.enabled && settings.celebrate) {
          window.UnclosedFX.celebrate();
          chrome.storage.local.get({ acCount: 0 }, ({ acCount }) =>
            chrome.storage.local.set({ acCount: acCount + 1 }));
        }
        break;
    }
  });

  // Popup asks for diagnostics or a confetti preview.
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg && msg.type === 'getStatus') reply({ ...status, enabled: settings.enabled });
    if (msg && msg.type === 'preview') { window.UnclosedFX.celebrate(); reply({ ok: true }); }
  });
})();
