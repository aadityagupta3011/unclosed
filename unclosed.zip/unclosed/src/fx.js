/*
 * Unclosed — visual effects (isolated world).
 * One full-screen canvas for confetti + sparkles, plus a shadow-DOM layer for
 * the toast and the "ACCEPTED" badge so LeetCode's CSS can't leak in or out.
 * Everything is pointer-events: none and removes itself when idle.
 */
(() => {
  'use strict';
  if (window.UnclosedFX) return;

  const COLORS = ['#a78bfa', '#f472b6', '#22d3ee', '#facc15', '#34d399', '#fb7185', '#ffffff'];
  const AC_LINES = [
    'ate that, no crumbs 💅',
    'no cap, that\'s an AC 🧢',
    'main character energy ✨',
    'W submission fr fr 🏆',
    'big brain behaviour 🧠',
    'the test cases said yes 😮‍💨',
    'slay. just slay. 💜',
    'understood the assignment 📝',
    'it\'s giving O(1) vibes 📈',
    'rent free in the judge\'s head 🏠',
  ];
  const reduceMotion = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------------- shadow layer ---------------- */
  let host, root;
  function layer() {
    if (host && host.isConnected) return root;
    host = document.createElement('unclosed-fx');
    host.style.cssText = 'all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483647;';
    root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `
      <style>
        :host { all: initial; }
        canvas { position: fixed; inset: 0; width: 100vw; height: 100vh; pointer-events: none; }
        .toast {
          position: fixed; top: 18px; left: 50%; transform: translate(-50%, -140%);
          display: flex; align-items: center; gap: 10px;
          padding: 10px 18px 10px 12px; border-radius: 999px;
          font: 600 14px/1.2 ui-rounded, "SF Pro Rounded", system-ui, -apple-system, "Segoe UI", sans-serif;
          color: #fff; letter-spacing: .1px; white-space: nowrap;
          background: linear-gradient(135deg, rgba(124,58,237,.96), rgba(219,39,119,.96));
          box-shadow: 0 10px 30px rgba(124,58,237,.35), 0 0 0 1px rgba(255,255,255,.18) inset;
          transition: transform .45s cubic-bezier(.2,1.4,.4,1), opacity .3s ease; opacity: 0;
        }
        .toast.off { background: linear-gradient(135deg, rgba(51,65,85,.96), rgba(30,41,59,.96)); box-shadow: 0 10px 30px rgba(15,23,42,.35), 0 0 0 1px rgba(255,255,255,.12) inset; }
        .toast.show { transform: translate(-50%, 0); opacity: 1; }
        .toast .emoji { font-size: 20px; }
        .toast small { display:block; font-weight: 500; opacity: .8; font-size: 12px; margin-top: 2px; }
        .badge {
          position: fixed; left: 50%; top: 42%; transform: translate(-50%, -50%) scale(.4);
          opacity: 0; text-align: center; padding: 22px 34px; border-radius: 26px;
          background: rgba(17, 12, 34, .78); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
          box-shadow: 0 20px 60px rgba(124,58,237,.45), 0 0 0 1px rgba(255,255,255,.12) inset;
          font-family: ui-rounded, "SF Pro Rounded", system-ui, -apple-system, "Segoe UI", sans-serif;
          transition: transform .55s cubic-bezier(.2,1.5,.35,1), opacity .35s ease;
        }
        .badge.show { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        .badge.hide { transform: translate(-50%, -60%) scale(.9); opacity: 0; transition-duration: .5s; }
        .badge .big {
          font-weight: 900; font-size: 46px; letter-spacing: 2px;
          background: linear-gradient(90deg, #a78bfa, #f472b6, #facc15, #34d399, #22d3ee, #a78bfa);
          background-size: 300% 100%; -webkit-background-clip: text; background-clip: text; color: transparent;
          animation: shimmer 2.2s linear infinite;
        }
        .badge .line { margin-top: 8px; color: #f5f3ff; font-size: 17px; font-weight: 600; }
        @keyframes shimmer { to { background-position: 300% 0; } }
        @media (prefers-reduced-motion: reduce) {
          .toast, .badge { transition: opacity .2s ease; }
          .badge .big { animation: none; }
        }
      </style>
      <canvas></canvas>`;
    (document.body || document.documentElement).appendChild(host);
    canvas = root.querySelector('canvas');
    ctx = canvas.getContext('2d');
    resize();
    return root;
  }

  /* ---------------- particles ---------------- */
  let canvas, ctx, raf = 0, dpr = 1, particles = [], idleTimer = 0;

  function resize() {
    if (!canvas) return;
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = innerWidth * dpr;
    canvas.height = innerHeight * dpr;
  }
  window.addEventListener('resize', resize, { passive: true });

  const rand = (a, b) => a + Math.random() * (b - a);
  const pick = (arr) => arr[(Math.random() * arr.length) | 0];

  function confetti(x, y, angle, spread, count, power) {
    for (let i = 0; i < count; i++) {
      const a = angle + rand(-spread, spread);
      const v = rand(power * 0.55, power);
      particles.push({
        kind: Math.random() < 0.7 ? 'paper' : 'dot',
        x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v,
        w: rand(6, 11), h: rand(8, 15), r: rand(0, Math.PI * 2), vr: rand(-0.25, 0.25),
        flip: rand(0, Math.PI * 2), vflip: rand(0.08, 0.2),
        color: pick(COLORS), life: 0, ttl: rand(150, 230), g: 0.22, drag: 0.985,
      });
    }
  }

  function sparkles(cx, cy, count, radius) {
    for (let i = 0; i < count; i++) {
      const a = rand(0, Math.PI * 2);
      const d = rand(0, radius);
      particles.push({
        kind: 'star', x: cx + Math.cos(a) * d, y: cy + Math.sin(a) * d,
        vx: Math.cos(a) * rand(0.2, 1.6), vy: Math.sin(a) * rand(0.2, 1.6) - 0.3,
        size: rand(5, 13), color: pick(['#ffffff', '#fde68a', '#f0abfc', '#a5f3fc', '#c4b5fd']),
        life: -((Math.random() * 25) | 0), ttl: rand(45, 90), g: 0.01, drag: 0.97, twinkle: rand(0.15, 0.35),
      });
    }
  }

  function drawStar(p, alpha) {
    const s = p.size * (0.6 + 0.4 * Math.abs(Math.sin(p.life * p.twinkle)));
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = p.color;
    ctx.shadowColor = p.color;
    ctx.shadowBlur = 12;
    ctx.beginPath(); // 4-point sparkle
    ctx.moveTo(0, -s);
    ctx.quadraticCurveTo(0, 0, s, 0);
    ctx.quadraticCurveTo(0, 0, 0, s);
    ctx.quadraticCurveTo(0, 0, -s, 0);
    ctx.quadraticCurveTo(0, 0, 0, -s);
    ctx.fill();
    ctx.restore();
  }

  function frame() {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    const next = [];
    for (const p of particles) {
      p.life++;
      if (p.life < 0) { next.push(p); continue; }
      p.vx *= p.drag; p.vy = p.vy * p.drag + p.g;
      p.x += p.vx; p.y += p.vy;
      const fade = Math.min(1, (p.ttl - p.life) / 30);
      if (p.life > p.ttl || p.y > innerHeight + 40) continue;
      next.push(p);
      if (p.kind === 'star') { drawStar(p, fade); continue; }
      p.r += p.vr; p.flip += p.vflip;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.r);
      ctx.globalAlpha = fade;
      ctx.fillStyle = p.color;
      if (p.kind === 'paper') {
        ctx.scale(1, Math.cos(p.flip)); // paper flutter
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      } else {
        ctx.beginPath(); ctx.arc(0, 0, p.w / 2.4, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
    }
    particles = next;
    if (particles.length) raf = requestAnimationFrame(frame);
    else { raf = 0; ctx.clearRect(0, 0, innerWidth, innerHeight); scheduleTeardown(); }
  }

  function run() {
    layer();
    clearTimeout(idleTimer);
    if (!raf) raf = requestAnimationFrame(frame);
  }

  function scheduleTeardown() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      if (!raf && host && !root.querySelector('.toast, .badge')) { host.remove(); host = null; }
    }, 1500);
  }

  /* ---------------- UI bits ---------------- */
  let toastEl, toastTimer;
  function toast(emoji, title, sub, on) {
    const r = layer();
    if (toastEl) toastEl.remove();
    clearTimeout(toastTimer);
    toastEl = document.createElement('div');
    toastEl.className = 'toast' + (on ? '' : ' off');
    const em = document.createElement('span'); em.className = 'emoji'; em.textContent = emoji;
    const txt = document.createElement('div'); txt.textContent = title;
    if (sub) { const s = document.createElement('small'); s.textContent = sub; txt.appendChild(s); }
    toastEl.append(em, txt);
    r.appendChild(toastEl);
    requestAnimationFrame(() => requestAnimationFrame(() => toastEl && toastEl.classList.add('show')));
    const el = toastEl;
    toastTimer = setTimeout(() => {
      el.classList.remove('show');
      setTimeout(() => { el.remove(); if (toastEl === el) toastEl = null; scheduleTeardown(); }, 500);
    }, 2400);
  }

  function badge() {
    const r = layer();
    r.querySelectorAll('.badge').forEach((b) => b.remove());
    const el = document.createElement('div');
    el.className = 'badge';
    const big = document.createElement('div'); big.className = 'big'; big.textContent = 'ACCEPTED';
    const line = document.createElement('div'); line.className = 'line'; line.textContent = pick(AC_LINES);
    el.append(big, line);
    r.appendChild(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('show')));
    setTimeout(() => el.classList.add('hide'), 2800);
    setTimeout(() => { el.remove(); scheduleTeardown(); }, 3400);
  }

  /* ---------------- public API ---------------- */
  window.UnclosedFX = {
    /** Big party for an Accepted submission. */
    celebrate() {
      badge();
      const W = innerWidth, H = innerHeight;
      if (reduceMotion()) { sparkles(W / 2, H * 0.42, 24, 160); run(); return; }
      confetti(0, H * 0.9, -Math.PI / 3.2, 0.45, 90, 19);          // left cannon
      confetti(W, H * 0.9, -Math.PI + Math.PI / 3.2, 0.45, 90, 19); // right cannon
      sparkles(W / 2, H * 0.42, 40, 220);
      setTimeout(() => { confetti(W / 2, -10, Math.PI / 2, 1.2, 70, 6); sparkles(W / 2, H * 0.42, 25, 260); }, 350);
      run();
    },
    /** Toggle feedback: sparkle burst + toast. */
    toggled(on) {
      if (on) {
        toast('🔓', 'brackets unclosed', 'auto-close is OFF — you type it, you own it', true);
        sparkles(innerWidth / 2, 40, reduceMotion() ? 10 : 34, 150);
        run();
      } else {
        toast('🫡', 'auto-close is back', 'ok boomer, LeetCode closes brackets again', false);
      }
    },
  };
})();
